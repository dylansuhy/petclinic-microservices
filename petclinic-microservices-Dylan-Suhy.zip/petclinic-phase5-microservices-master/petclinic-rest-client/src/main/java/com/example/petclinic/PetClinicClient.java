package com.example.petclinic;

import com.example.petclinic.business.PetClinicBusinessWorkflow;
import org.apache.catalina.core.ApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.example.petclinic.config.RestConfig;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class PetClinicClient {

    public static void main(String[] args) {
        //ApplicationContext context = SpringApplication.run(PetClinicClient.class, args);
        ConfigurableApplicationContext context = SpringApplication.run(PetClinicClient.class,args);
        PetClinicBusinessWorkflow business = (PetClinicBusinessWorkflow) context.getBean("petClinicBusinessWorkflow");

        business.runBusiness();
    }
}
