package com.example.petclinic.model;

public enum Speciality {

    NONE, RADIOLOGY, DENTISTRY, SURGERY

}
