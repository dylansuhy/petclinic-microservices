package com.example.petclinic.business;

import com.example.petclinic.model.Owner;
import com.example.petclinic.model.Pet;
import com.example.petclinic.model.PetType;
import com.example.petclinic.service.OwnerService;
import com.example.petclinic.service.PetService;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class PetClinicBusinessWorkflow {

    OwnerService ownerService;
    PetService petService;

    public PetClinicBusinessWorkflow(OwnerService ownerService) {
        this.ownerService = ownerService;
    }


    public void runBusiness() {

        String simpsonAddress = "742 Evergreen Terrace";
        String simpsonCity = "Springfield";
        String simpsonPhone = "9395550113";
        Owner owner1 = Owner.builder().withName("Homer Simpson").withAddress(simpsonAddress).withCity(simpsonCity).withPhoneNumber(simpsonPhone).build();
        Owner owner2 = Owner.builder().withName("Marge Simpson").withAddress(simpsonAddress).withCity(simpsonCity).withPhoneNumber(simpsonPhone).build();
        Owner owner3 = Owner.builder().withName("Bart Simpson").withAddress(simpsonAddress).withCity(simpsonCity).withPhoneNumber(simpsonPhone).build();
        Owner owner4 = Owner.builder().withName("Lisa Simpson").withAddress(simpsonAddress).withCity(simpsonCity).withPhoneNumber(simpsonPhone).build();

        ownerService.saveOwner(owner1);
        ownerService.saveOwner(owner2);
        ownerService.saveOwner(owner3);
        ownerService.saveOwner(owner4);

        ownerService.getAllOwners();

        ownerService.deleteOwner(owner1);


    }


}
