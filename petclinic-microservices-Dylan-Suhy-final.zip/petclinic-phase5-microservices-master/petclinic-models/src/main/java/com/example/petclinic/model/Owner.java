package com.example.petclinic.model;

public class Owner {


}
